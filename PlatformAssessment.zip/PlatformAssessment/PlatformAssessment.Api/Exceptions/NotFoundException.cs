﻿using System;

namespace PlatformAssessment.Api.Exceptions
{
    public class NotFoundException : ApplicationException
    {
        public NotFoundException(object id)
            : base($"User with id {id} not found")
        {
        }
    }
}
