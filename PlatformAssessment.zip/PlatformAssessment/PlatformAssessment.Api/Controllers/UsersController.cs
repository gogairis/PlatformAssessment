﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PlatformAssessment.Api.Features.Users.Commands.CreateUser;
using PlatformAssessment.Api.Features.Users.Commands.DeleteUser;
using PlatformAssessment.Api.Features.Users.Commands.UpdateUser;
using PlatformAssessment.Api.Features.Users.Queries.GetUsersList;
using System.Collections.Generic;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PlatformAssessment.Api.Controllers
{
    [Route("api/users")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        public readonly IMediator _mediator;

        public UsersController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesDefaultResponseType]
        public async Task<ActionResult<List<UserListVm>>> GetUsersList()
        {
            var dtos = await _mediator.Send(new GetUsersListQuery());
            return Ok(dtos);
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesDefaultResponseType]
        public async Task<ActionResult<int>> Create([FromBody] CreateUserCommand createUserCommand)
        {
            var response = await _mediator.Send(createUserCommand);

            return response.Success ? Ok(response.Id) : BadRequest(response.ValidationErrors);
        }

        [HttpPut("{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesDefaultResponseType]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateUserRequestBody updateUserRequestBody)
        {
            var updateUserCommand = new UpdateUserCommand()
            {
                UserId = id,
                UserName = updateUserRequestBody.UserName
            };
            
            var response = await _mediator.Send(updateUserCommand);


            return response.Success ? NoContent() : BadRequest(response.ValidationErrors);
        }

        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesDefaultResponseType]
        public async Task<IActionResult> Delete(int id)
        {
            var deleteUserCommand = new DeleteUserCommand() { UserId = id };

            await _mediator.Send(deleteUserCommand);
            return NoContent();
        }
    }
}
