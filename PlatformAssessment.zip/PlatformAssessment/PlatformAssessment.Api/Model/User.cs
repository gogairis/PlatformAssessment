﻿namespace PlatformAssessment.Api.Model
{
    public class User
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
    }
}
