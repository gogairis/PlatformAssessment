﻿namespace PlatformAssessment.Api.Features.Users.Queries.GetUsersList
{
    public class UserListVm
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
    }
}
