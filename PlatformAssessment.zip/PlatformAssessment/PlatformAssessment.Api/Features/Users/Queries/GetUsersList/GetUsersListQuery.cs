﻿using MediatR;
using System.Collections.Generic;

namespace PlatformAssessment.Api.Features.Users.Queries.GetUsersList
{
    public class GetUsersListQuery: IRequest<List<UserListVm>>
    {
    }
}
