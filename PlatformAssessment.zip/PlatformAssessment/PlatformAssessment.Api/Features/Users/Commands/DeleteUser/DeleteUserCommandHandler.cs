﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using PlatformAssessment.Api.Contracts;
using PlatformAssessment.Api.Exceptions;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace PlatformAssessment.Api.Features.Users.Commands.DeleteUser
{
    public class DeleteUserCommandHandler : IRequestHandler<DeleteUserCommand>
    {
        public DeleteUserCommandHandler(IMapper mapper, IUserRepository userRepository, ILogger<DeleteUserCommandHandler> logger)
        {
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _userRepository = userRepository ?? throw new ArgumentNullException(nameof(userRepository));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public IMapper _mapper { get; }
        public IUserRepository _userRepository { get; }
        public ILogger<DeleteUserCommandHandler> _logger { get; }

        public async Task<Unit> Handle(DeleteUserCommand request, CancellationToken cancellationToken)
        {
            var userToDelete = await _userRepository.GetByIdAsync(request.UserId);
            
            if (userToDelete == null)
            {
                throw new NotFoundException(request.UserId);
            }

            await _userRepository.DeleteAsync(userToDelete);

            return Unit.Value;
        }
    }
}
