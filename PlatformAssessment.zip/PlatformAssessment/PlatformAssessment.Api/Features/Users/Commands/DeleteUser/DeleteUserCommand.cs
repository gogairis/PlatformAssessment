﻿using MediatR;
using PlatformAssessment.Api.Model;

namespace PlatformAssessment.Api.Features.Users.Commands.DeleteUser
{
    public class DeleteUserCommand : IRequest
    {
        public int UserId { get; set; }
    }
}
