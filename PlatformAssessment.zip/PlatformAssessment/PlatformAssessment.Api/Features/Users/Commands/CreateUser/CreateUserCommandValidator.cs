﻿using FluentValidation;
using PlatformAssessment.Api.Contracts;
using System.Threading;
using System.Threading.Tasks;

namespace PlatformAssessment.Api.Features.Users.Commands.CreateUser
{
    public class CreateUserCommandValidator : AbstractValidator<CreateUserCommand>
    {
        public CreateUserCommandValidator(IUserRepository userRepository)
        {
            UserRepository = userRepository;

            RuleFor(p => p.UserName)
                .NotEmpty().WithMessage("{PropertyName} is required.")
                .NotNull();

            RuleFor(e => e)
                .MustAsync(UserNameUnique)
                .WithMessage("A user with same name already exists.");

        }

        private async Task<bool> UserNameUnique(CreateUserCommand e, CancellationToken token)
        {
            return !(await UserRepository.IsUserNameUnique(e.UserName));
        }

        public IUserRepository UserRepository { get; }
    }
}
