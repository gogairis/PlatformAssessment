﻿using MediatR;

namespace PlatformAssessment.Api.Features.Users.Commands.CreateUser
{
    public class CreateUserCommand : IRequest<CreateUserCommandResponse>
    {
        public string UserName { get; set; }
    }
}
