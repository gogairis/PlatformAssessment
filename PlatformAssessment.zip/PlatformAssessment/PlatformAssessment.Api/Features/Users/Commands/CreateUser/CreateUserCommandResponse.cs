﻿using PlatformAssessment.Api.Responses;

namespace PlatformAssessment.Api.Features.Users.Commands.CreateUser
{
    public class CreateUserCommandResponse : BaseResponse
    {
        public int Id { get; set; }
    }
}
