﻿using MediatR;

namespace PlatformAssessment.Api.Features.Users.Commands.UpdateUser
{
    public class UpdateUserCommand : IRequest<UpdateUserCommandResponse>
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
    }
}
