﻿using FluentValidation;
using PlatformAssessment.Api.Contracts;
using System.Threading;
using System.Threading.Tasks;

namespace PlatformAssessment.Api.Features.Users.Commands.UpdateUser
{
    public class UpdateUserCommandValidator : AbstractValidator<UpdateUserCommand>
    {
        public UpdateUserCommandValidator(IUserRepository userRepository)
        {
            UserRepository = userRepository;

            RuleFor(p => p.UserName)
                .NotEmpty().WithMessage("{PropertyName} is required.")
                .NotNull();

            RuleFor(e => e)
                .MustAsync(UserNameUnique)
                .WithMessage("A user with same name already exists.");

        }

        private async Task<bool> UserNameUnique(UpdateUserCommand e, CancellationToken token)
        {
            return !(await UserRepository.IsUserNameUnique(e.UserName));
        }

        public IUserRepository UserRepository { get; }
    }
}
