﻿namespace PlatformAssessment.Api.Features.Users.Commands.UpdateUser
{
    public class UpdateUserRequestBody
    {
        public string UserName { get; set; }
    }
}
