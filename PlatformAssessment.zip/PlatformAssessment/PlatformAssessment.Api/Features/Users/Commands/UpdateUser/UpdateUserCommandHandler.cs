﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using PlatformAssessment.Api.Contracts;
using PlatformAssessment.Api.Exceptions;
using PlatformAssessment.Api.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PlatformAssessment.Api.Features.Users.Commands.UpdateUser
{
    public class UpdateUserCommandHandler : IRequestHandler<UpdateUserCommand, UpdateUserCommandResponse>
    {
        public UpdateUserCommandHandler(IMapper mapper, IUserRepository userRepository, ILogger<UpdateUserCommandHandler> logger)
        {
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _userRepository = userRepository ?? throw new ArgumentNullException(nameof(userRepository));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public IMapper _mapper { get; }
        public IUserRepository _userRepository { get; }
        public ILogger<UpdateUserCommandHandler> _logger { get; }

        public async Task<UpdateUserCommandResponse> Handle(UpdateUserCommand request, CancellationToken cancellationToken)
        {
            var response = new UpdateUserCommandResponse();
            var userToUpdate = await _userRepository.GetByIdAsync(request.UserId);

            if (userToUpdate == null)
            {
                throw new NotFoundException(request.UserId);
            }

            var validator = new UpdateUserCommandValidator(_userRepository);
            var validationResult = await validator.ValidateAsync(request);

            if (validationResult.Errors.Any())
            {
                response.Success = false;
                response.ValidationErrors = new List<string>();

                foreach(var error in validationResult.Errors)
                {
                    response.ValidationErrors.Add(error.ErrorMessage);
                }
                return response;
            }
            
            _mapper.Map(request, userToUpdate, typeof(UpdateUserCommand), typeof(User));

            await _userRepository.UpdateAsync(userToUpdate);
            response.Success = true;

            return response;
        }
    }
}
