﻿using PlatformAssessment.Api.Responses;

namespace PlatformAssessment.Api.Features.Users.Commands.UpdateUser
{
    public class UpdateUserCommandResponse : BaseResponse
    {
    }
}
