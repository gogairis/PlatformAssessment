﻿using PlatformAssessment.Api.Model;
using System.Threading.Tasks;

namespace PlatformAssessment.Api.Contracts
{
    public interface IUserRepository : IAsyncRepository<User>
    {
        Task<bool> IsUserNameUnique(string userName);
    }
}
