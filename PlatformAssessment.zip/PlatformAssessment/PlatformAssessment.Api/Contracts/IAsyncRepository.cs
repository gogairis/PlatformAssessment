﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace PlatformAssessment.Api.Contracts
{
    public interface IAsyncRepository<T> where T : class
    {
        Task<T> GetByIdAsync(int id);
        Task<T> AddAsync(T entity);
        Task<IReadOnlyList<T>> ListAllAsync();
        Task UpdateAsync(T entity);
        Task DeleteAsync(T entity);
    }
}
