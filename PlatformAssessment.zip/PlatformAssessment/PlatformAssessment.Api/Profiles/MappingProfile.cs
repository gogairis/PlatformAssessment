﻿using AutoMapper;
using PlatformAssessment.Api.Features.Users.Commands.CreateUser;
using PlatformAssessment.Api.Features.Users.Commands.UpdateUser;
using PlatformAssessment.Api.Features.Users.Queries.GetUsersList;
using PlatformAssessment.Api.Model;

namespace PlatformAssessment.Api.Profiles
{
    public class MappingProfile: Profile
    {
        public MappingProfile()
        {
            CreateMap<User, UserListVm>().ReverseMap();
            CreateMap<User, CreateUserCommand>().ReverseMap();
            CreateMap<User, UpdateUserCommand>().ReverseMap();
        }
    }
}
