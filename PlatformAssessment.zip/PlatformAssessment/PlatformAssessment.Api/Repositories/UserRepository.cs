﻿using PlatformAssessment.Api.Contracts;
using PlatformAssessment.Api.Model;
using System.Linq;
using System.Threading.Tasks;

namespace PlatformAssessment.Api.Repositories
{
    public class UserRepository : BaseRepository<User>, IUserRepository
    {
        public UserRepository(ApiContext dbContext) 
            : base(dbContext)
        {

        }
        public Task<bool> IsUserNameUnique(string name)
        {
            var matches = _dbContext.Users.Any(e => e.UserName.Equals(name));
            return Task.FromResult(matches);
        }
    }
}
