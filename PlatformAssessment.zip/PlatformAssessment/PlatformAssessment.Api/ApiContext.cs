﻿using Microsoft.EntityFrameworkCore;
using PlatformAssessment.Api.Model;

namespace PlatformAssessment.Api
{
    public class ApiContext : DbContext
    {
        public ApiContext(DbContextOptions<ApiContext> options)
            : base(options)
        {

        }
        public DbSet<User> Users { get; set; }
    }
}
