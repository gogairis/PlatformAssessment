﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using PlatformAssessment.Api.Controllers;
using PlatformAssessment.Api.Exceptions;
using PlatformAssessment.Api.Features.Users.Commands.CreateUser;
using PlatformAssessment.Api.Features.Users.Commands.DeleteUser;
using PlatformAssessment.Api.Features.Users.Commands.UpdateUser;
using PlatformAssessment.Api.Features.Users.Queries.GetUsersList;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Xunit;


namespace PlatformAssessment.UnitTests.Controllers
{
    [Trait("Api.Controllers", "Users")]
    public class UserControllerTests
    {
        private readonly Mock<IMediator> _mediator;
        public UserControllerTests()
        {
            _mediator = new Mock<IMediator>(MockBehavior.Strict);
        }

        [Fact]
        public async Task GetUsersListTest()
        {
            // Arrange
            _mediator.Setup(m => m.Send(It.IsAny<GetUsersListQuery>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(It.IsAny<List<UserListVm>>())
                .Verifiable();

            // Act
            var sut = new UsersController(_mediator.Object);
            var result = await sut.GetUsersList();

            // Assert
            Assert.NotNull(result);
            _mediator.Verify();
        }

        [Theory]
        [InlineData(true)]   // To simulate OkResponse
        [InlineData(false)]  // To simulate BadRequest
        public async Task CreateNewUserTest(bool success)
        {
            // Arrange
            var createUserCommand = new CreateUserCommand()
            {
                UserName = "New Test User"
            };

            var expected = new CreateUserCommandResponse() { Success = success };

            _mediator.Setup(m => m.Send(It.Is<CreateUserCommand>(c =>
                c.UserName == createUserCommand.UserName), It.IsAny<CancellationToken>()))
                .ReturnsAsync(expected)
                .Verifiable();

            // Act
            var sut = new UsersController(_mediator.Object);
            var result = await sut.Create(createUserCommand);

            // Assert
            Assert.NotNull(result);

            CreateUserCommandResponse response;
            if (success)
            {
                Assert.True(result.Result is OkObjectResult);
                var okResult = result.Result as OkObjectResult;
                Assert.NotNull(okResult);
                response = okResult.Value as CreateUserCommandResponse;
            }
            else
            {
                Assert.True(result.Result is BadRequestObjectResult);
                var badResult = result.Result as BadRequestObjectResult;
                Assert.NotNull(badResult);
                response = badResult.Value as CreateUserCommandResponse;
            }
            response?.Success.Equals(success);
            _mediator.Verify();
        }

        [Theory]
        [InlineData(true)]   // To simulate OkResponse
        [InlineData(false)]  // To simulate BadRequest
        public async Task UpdateUserTest(bool success)
        {
            // Arrange
            var updateUserRequestBody = new UpdateUserRequestBody()
            {
                UserName = "Modified User Name"
            };

            var updateUserCommand = new UpdateUserCommand()
            {
                UserId = 1,
                UserName = updateUserRequestBody.UserName
            };

            var expected = new UpdateUserCommandResponse() { Success = success };

            _mediator.Setup(m => m.Send(It.Is<UpdateUserCommand>(c =>
                c.UserId == updateUserCommand.UserId &&
                c.UserName == updateUserCommand.UserName), It.IsAny<CancellationToken>()))
                .ReturnsAsync(expected)
                .Verifiable();

            // Act
            var sut = new UsersController(_mediator.Object);
            var result = await sut.Update(updateUserCommand.UserId, updateUserRequestBody);

            // Assert
            Assert.NotNull(result);

            if (success)
            {
                Assert.True(result is NoContentResult);
                var okResult = result as OkObjectResult;
                Assert.Null(okResult);
            }
            else
            {
                Assert.True(result is BadRequestObjectResult);
                var badResult = result as BadRequestObjectResult;
                Assert.NotNull(badResult);
            }
            _mediator.Verify();
        }

        [Fact]
        public void UpdateUser_InvalidId_ThrowsNotFoundException()
        {
            // Arrange
            var updateUserRequestBody = new UpdateUserRequestBody()
            {
                UserName = "Modified User Name"
            };

            var updateUserCommand = new UpdateUserCommand()
            {
                UserId = 1,
                UserName = updateUserRequestBody.UserName
            };

            _mediator.Setup(m => m.Send(It.Is<UpdateUserCommand>(c =>
                c.UserId == updateUserCommand.UserId &&
                c.UserName == updateUserCommand.UserName), It.IsAny<CancellationToken>()))
                .Throws(new NotFoundException(updateUserCommand.UserId))
                .Verifiable();

            // Act
            var sut = new UsersController(_mediator.Object);

            // Assert
            Assert.ThrowsAsync<NotFoundException>(() => sut.Update(updateUserCommand.UserId, updateUserRequestBody));
            _mediator.Verify();
        }

        [Fact]
        public async Task DeleteUserTest()
        {
            // Arrange
            var deleteUserCommand = new DeleteUserCommand()
            {
                UserId = 1
            };

            _mediator.Setup(m => m.Send(It.Is<DeleteUserCommand>(c =>
                c.UserId == deleteUserCommand.UserId), It.IsAny<CancellationToken>()))
                .ReturnsAsync(It.IsAny<Unit>())
                .Verifiable();

            // Act
            var sut = new UsersController(_mediator.Object);
            var result = await sut.Delete(deleteUserCommand.UserId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result is NoContentResult);
            _mediator.Verify();
        }

        [Fact]
        public void DeleteUser_InvalidId_ThrowsNotFoundException()
        {
            // Arrange
            var deleteUserCommand = new DeleteUserCommand()
            {
                UserId = 1
            };

            _mediator.Setup(m => m.Send(It.Is<DeleteUserCommand>(c =>
                c.UserId == deleteUserCommand.UserId), It.IsAny<CancellationToken>()))
                .Throws(new NotFoundException(deleteUserCommand.UserId))
                .Verifiable();

            // Act
            var sut = new UsersController(_mediator.Object);
            
            // Assert
            Assert.ThrowsAsync<NotFoundException>(()=> sut.Delete(deleteUserCommand.UserId));
            _mediator.Verify();
        }
    }
}
